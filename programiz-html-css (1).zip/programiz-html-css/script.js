let timerInterval;
let timeRemaining;

// Function to start the timer
function startTimer() {
  const hoursInput = document.getElementById('hours').value;
  const minutesInput = document.getElementById('minutes').value;

  // Convert user input into total seconds
  timeRemaining = (parseInt(hoursInput) * 60 * 60) + (parseInt(minutesInput) * 60);

  // Start the countdown timer
  if (timerInterval) {
    clearInterval(timerInterval);  // Clear any existing timer
  }

  timerInterval = setInterval(updateTimer, 1000);
  updateTimer();  // Initialize the timer immediately
}

// Function to update the timer display
function updateTimer() {
  const hours = Math.floor(timeRemaining / 3600);
  const minutes = Math.floor((timeRemaining % 3600) / 60);
  const seconds = timeRemaining % 60;

  // Format time to always show two digits
  document.getElementById('hoursDisplay').textContent = String(hours).padStart(2, '0');
  document.getElementById('minutesDisplay').textContent = String(minutes).padStart(2, '0');
  document.getElementById('secondsDisplay').textContent = String(seconds).padStart(2, '0');

  if (timeRemaining > 0) {
    timeRemaining--;
  } else {
    clearInterval(timerInterval);
    alert("Time's up! The exam is over.");
  }
}

// Event listener for the start button
document.getElementById('startButton').addEventListener('click', function() {
  startTimer();  // Start the timer when the button is clicked
});

